/**
 * @file    Display Level for table columns
 * @version 0.1
 * @Date    2024/06/25
 * @author  TA_金秀
 **/

import { useState, } from "react";

interface IDispLvParam {
  dispLevels: string[];
  dispLv:     string;
  setDispLv:  (s: string) => void;
}
export const useDispLv = (dispLevels: string[], defLv?: string) => {
  const [dispLv, setDispLv]  = useState(defLv || dispLevels[dispLevels.length-1]);

  return ({
    dispLevels,
    dispLv, setDispLv
  });
}

export const DispLv = ({dispLevels, dispLv, setDispLv}: IDispLvParam) =>
  <label>
    ■表示ﾚﾍﾞﾙ
    <select value={dispLv} onChange={ev => setDispLv(ev.target.value)}>
      {dispLevels.map((_op, k) => <option key={k}>{dispLevels[k]}</option>)}
    </select>
  </label>;
