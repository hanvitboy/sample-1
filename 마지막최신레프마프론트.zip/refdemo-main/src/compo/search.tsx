/**
 * @file    search 検索ツール
 * @version 0.1
 * @Date    2024/06/20
 * @author  TA_金秀
 * - Reuse mechanism using React Hooks: custom hooks let you share stateful logic,
 *   not state itself.
 **/
import { type PropsWithChildren, useState, } from 'react';
import { TagsInput, } from 'compo/tags';
import { TDataLine, } from 'util/loader';
import { LabeledSwitch, } from 'util/ux';
import { type IDropdownMenuItem, DropdownMenu, } from 'util/ux';
import 'styles/search.css';

export const MatchCounter = ({matchCnt, total}: {
  matchCnt?: number;
  total:     number;
}) =>
  <div className='countsCont'
    style={{ visibility: total ? 'visible' : 'hidden' }}
  >
    <div className='counts'>
      {(matchCnt !== undefined) && <span data-c={matchCnt}>{matchCnt}</span>}
      <span>{total}</span>
    </div>
    件
  </div>;

export const useSearch = (menu: IDropdownMenuItem[], body: TDataLine[]) => {
  const [sel,  setSel]  = useState(0);             // menu selection
  const [tags, setTags] = useState<string[]>([]);  // search keywords
  const [hi,   setHi]   = useState(true);          // turn on/off syntaxt highlight

  let fRes = (tags.length && body.length)
    ? body.filter(rec =>
        rec.some(col =>
          tags.some(tag => col?.toString().includes(tag))  // search
        ))
    : body;
  const matchCnt = body.length ? fRes.length : undefined;
  if (matchCnt === 0)  // 検索結果が0で何も表示しない画面になることを防ぐため
    fRes = body;

  return ({  // all the variables to inject search functionality
    menu,
    sel,  setSel,
    tags, setTags,
    hi,   setHi,
    matchCnt,
    total: body.length,
    fRes,
  });
}

interface ISearchParam {  // search result
  menu:      IDropdownMenuItem[];
  sel:       number;
  setSel:    IDropdownMenuItem['onMenuItem'];
  tags:      string[];
  setTags:   (ts: string[]) => void;
  hi:        boolean;
  setHi:     (h: boolean) => void;
  matchCnt?: number;                  // match count
  total:     number;
}

export const SearchInput = ({
  menu,
  sel,  setSel,
  tags, setTags,
  hi,   setHi,
  matchCnt,
  total,
  children
}:
  PropsWithChildren<ISearchParam>
) => {
  return (
    <div className='searchui'>
      <TagsInput {...{tags, setTags, matchCnt}}>
        <DropdownMenu {...{menu, sel, setSel}} />
      </TagsInput>
      <MatchCounter {...{matchCnt, total}} />
      <LabeledSwitch enable={hi} setEnable={setHi}>ﾊｲﾗｲﾄ</LabeledSwitch>
      {children}
    </div>);
}

/**
 *  Highlight src text for matching tags
 *  1. parse src for each tag
 *  2. build markup with the parsed parts
 *  - part: parsed text
 *  - id: matching tag id (required for coloring), undefined if no match
 *  '渋谷'.split(new RegExp('(渋谷)', 'gi')) → ['', '渋谷', ''] so need to filter(p => p)
 */
export function HiTags(tags?: string[], src?: string0|number) {
  if (!tags || !tags.length || !src)
    return src;
  const srcText = (typeof src === 'number') ? src.toString() : src;
  const aS: { part: string; id?: number; }[] = [{ part: srcText, }];
  tags.forEach((tag, id) =>
    aS.forEach((s, i) => {
      if (s.id === undefined) {  // no match yet
        const parts = s.part.split(new RegExp(`(${tag})`, 'gi'));  // check occurrence of tag
        // if no matches, returns an array of the entire string
        if (parts.length > 1) {
          // replace aS[i] with new array
          aS.splice(i, 1, ...parts.filter(p => p)  // exclude any ''
            .map(part => (part === tag) ? {part, id} : {part}));
        }
      }
    })
  );
  return (aS.length === 1 && aS[0].id === undefined)  // no match, trivial case
  ? src
  : <>{aS.map((s, i) => 
        (s.id === undefined)
        ? s.part
        : <span key={i} className='hi' data-i={s.id}>{s.part}</span>)}
    </>;
}

