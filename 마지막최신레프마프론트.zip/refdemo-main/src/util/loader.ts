/**
 * @file    Data Loader and Parser
 * @version 0.5
 * @Date    2024/06/18
 * @author  TA_金秀
 * 2024/06/27 select & transformer → select
 **/
import { useState, useEffect, } from 'react';
import Papa from 'papaparse';

export type TDataLine = Array<string|number|null>;
export interface IDataMapper {  // call signature
  (r: TDataLine): TDataLine;
}

export const xNULL = (v: string|number|null) => v && v === 'NULL' ? null : v;

export const useLoadParseData = (
  reload:       number,                // fetch reload count
  url:          string,
  select:       IDataMapper,
  delayMs:      number,                // delay effect for demo
  onDataReady?: (data: TDataLine[]) => TDataLine[],  // last chance to process data as the side effect
  onError?:     (msg: string) => void, // callback on error
  onStart?:     (ts: Date) => void,
  onEnd?:       () => void
) => {
  const [headRaw, setHeadRaw] = useState<TDataLine>([]);
  const [bodyRaw, setBodyRaw] = useState<TDataLine[]>([]);

  useEffect(() => {
    const f = async () => {
      try {
        const res = await fetch(url);
        if (res?.ok) {
          console.log('fetch:', res);
          const txt = await res.text();
          const csv = Papa.parse(txt, { dynamicTyping: true, });
          if (!csv.errors.length) {
            console.log(`${csv.data.length} rows`);
            setHeadRaw(select(csv.data[0] as TDataLine));  // first row is a header
            const data = (csv.data.slice(1) as TDataLine[])      // skip header row
              .filter(r => r[0])                               // exclude empty row
              .map(r => select(r)) as TDataLine[];
            setBodyRaw(onDataReady ? onDataReady(data) : data);
          } else
            console.error('Empty data!');
          // console.log(csv);
        } else {
          console.error('fetch: error!', res.status, res.statusText);
          onError?.(res.statusText);
        }
      } catch (error) {
        console.error(error);
        alert('ファイル受信失敗：' + error);
      } finally {
        onEnd?.();
      }
    }
    onStart?.(new Date());
    setTimeout(f, delayMs);
  }, [reload, url]);  // By changing fetchTs, rerun the fetch with the same url

  return ({
    bodyRaw,
    headRaw,
  });
} 
