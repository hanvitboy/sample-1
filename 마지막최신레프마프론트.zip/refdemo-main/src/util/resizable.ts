/**
 * @file    Table Resizer 
 * @version 1.2.0
 * @Date 2024/06/06, 06/09 Apply resizong only when the mouse move ends
 * @author  TA_金秀
 *
 * TODO: render props to hooks
 */

// Fit cell width to content ⇒ { white-space: nowrap; }

import type { ReactElement, FC, } from 'react';
import { useState, useCallback, useEffect, } from 'react';
// import icoResize from './Images/resize-hand.svg';
import 'styles/resizer.css';

interface IResizable {
  children({ ref }: { ref: (nodeEle: HTMLDivElement) => void }): ReactElement; 
}

export const Resizable: FC<IResizable> = ({ children }) => {
  const [node, setNode] = useState<HTMLDivElement|null>(null);
  const CLS_TABLE_RESIZING = 'table-resizing';
  const CLS_COL_RESIZING   = 'col-resizing';    // CSS can handle on this class

  const ref = useCallback((nodeEle: HTMLDivElement) => {
    setNode(nodeEle);
  }, []);

  const handleMouseDown = useCallback((ev: MouseEvent) => {
    const parent = node?.parentElement;
    if (!parent)
      return;
    const startPosX = ev.clientX;
    const styles = window.getComputedStyle(parent);
    const w = parseInt(styles.width, 10);

    // const handleMouseMove = (_e: MouseEvent) => {
    //   updateCursor();
    //   // console.log(w, dx);
    // };

    const handleMouseUp = (e: MouseEvent) => {
      const dx = e.clientX - startPosX;
      parent.style.minWidth = `${w + dx}px`;  // style.width will not work with no enough space
      parent.classList.remove(CLS_COL_RESIZING );
      document.body.classList.remove(CLS_TABLE_RESIZING);
      // document.removeEventListener('mousemove', handleMouseMove);
      document.removeEventListener('mouseup',   handleMouseUp);
    }

    parent.classList.add(CLS_COL_RESIZING);
    document.body.classList.add(CLS_TABLE_RESIZING);
    // document.addEventListener('mousemove', handleMouseMove);
    document.addEventListener('mouseup',   handleMouseUp);
  }, [node]);

  const handleTouchStart = useCallback((ev: TouchEvent) => {
    const parent = node?.parentElement;
    if (!parent)
      return;
    const startPosX = ev.touches[0].clientX - 10;  // unsure 
    const styles = window.getComputedStyle(parent);
    const w = parseInt(styles.width, 10);

    // const handleTouchMove = (_e: TouchEvent) => {
    //   updateCursor();
    // }

    const handleTouchEnd = (e: TouchEvent) => {
      const dx = e.touches[0].clientX - startPosX;
      parent.style.minWidth = `${w + dx}px`;
      parent.classList.remove(CLS_COL_RESIZING );
      // document.removeEventListener('touchmove', handleTouchMove);
      document.removeEventListener('touchend',  handleTouchEnd);
      // resetCursor();
    }

    parent.classList.add(CLS_COL_RESIZING);
    // document.addEventListener('touchmove', handleTouchMove);
    document.addEventListener('touchend',  handleTouchEnd);
  }, [node]);

  // https://www.svgrepo.com/
  // const updateCursor = () => {  // svg ⇒ Data URI (https://yoksel.github.io/url-encoder/)
    // document.body.style.userSelect = 'none';  // disable selecting text
  // }

  // const resetCursor = () => {
    // document.body.style.removeProperty('user-select');
  // }

  useEffect(() => {
    if (!node)
      return;
    node.addEventListener("mousedown",  handleMouseDown);
    node.addEventListener("touchstart", handleTouchStart);

    return () => {
      node.removeEventListener("mousedown",  handleMouseDown);
      node.removeEventListener("touchstart", handleTouchStart);
    };
  }, [node]);

  return children({ ref });
}

/*
 * TEST

    <div className='lIE'>
      <table className={'lIE1 lv' + dispLv}>
        <thead>
          <tr>
          {["Column11", "Column12", "Column13"].map((title, i) =>
            <Resizable key={i}>
            {({ref}) => (
              <th rowSpan={i === 1 ? 1 : 2} colSpan={i === 1 ? 3 : 1}
                onClick={_ev => console.log('click')}
              >
                  {title}
                  <div className="resizer" ref={ref} />
              </th>)
            }
            </Resizable>)}
          </tr>
          <tr>
          {["Column21", "Column22", "Column23"].map((title, i) =>
            <Resizable key={i}>
            {({ref}) => (
              <th className="column">
                  {title}
                  <div className="resizer" ref={ref} />
              </th>)
            }
            </Resizable>)}
          </tr>
        </thead>
        <tbody>
              <tr>
                  <td>1</td>
                  <td>REFMa</td>
                  <td>Hitachi</td>
                  <td>A</td>
                  <td>B</td>
              </tr>
              <tr>
                  <td>2</td>
                  <td>大森</td>
                  <td>東京</td>
                  <td>A</td>
                  <td>B</td>
              </tr>
              <tr>
                  <td>3</td>
                  <td>秋葉原</td>
                  <td>スカイツリー</td>
                  <td>A</td>
                  <td>B</td>
              </tr>
              <tr>
                  <td>4</td>
                  <td>上野</td>
                  <td>UE</td>
                  <td>A</td>
                  <td>B</td>
              </tr>
              <tr>
                  <td>5</td>
                  <td>御徒町</td>
                  <td>横浜</td>
                  <td>A</td>
                  <td>B</td>
              </tr>
          </tbody>
      </table>

 */
