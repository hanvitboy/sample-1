/**
 * @file    ux - UI components
 * @version 1.0.0
 * @Date 2024/06/04
 * @author  TA_金秀
 */
import { type PropsWithChildren, useState, } from 'react';
import { cLo, } from 'util/util';
import { Switch, Dialog, DialogPanel, DialogTitle,
  Transition, TransitionChild, Checkbox,
  Menu, MenuButton, MenuItem, MenuItems,
} from '@headlessui/react';
import {
  CheckCircleIcon as CheckCircleIconO,
  XMarkIcon as XMarkIconO,
  CheckIcon,
} from '@heroicons/react/24/outline';
import {
  XMarkIcon, XCircleIcon,
} from '@heroicons/react/20/solid';
import { ChevronDownIcon,
} from '@heroicons/react/16/solid'

// input:  01_電力【電路】
// output: { num: '❶', text: '電力【電路】' }
export const maruNum = (text: string, kind: 0|1=0) => {
  const p = text.split('_');
  if (!p || p.length <= 1)
    return ({ num: '', text });
  const i = Number(p[0]);
  const maru = [
    '⓪①②③④⑤⑥⑦⑧⑨⑩⑪⑫⑬⑭⑮⑯⑰⑱⑲⑳',
    '⓿❶❷❸❹❺❻❼❽❾❿⓫⓬⓭⓮⓯⓰⓱⓲⓳⓴',
  ];
  return ({
    num:  i <= maru[0].length ? maru[kind][i] : `(${i})`,
    text: text.substring(p[0].length+1),
  });  // rest of input text
}

/**
 *  srcText: source text
 * highlight: substring to be highlighted
 * CSS - span.hi
 * RegEx () - capturing group
 */
export function HiText(hi?: string0, src?: string0|number) {
  // Split on highlight term and include term into parts, ignore case
  if (!hi || !src)
    return src;
  const srcText = (typeof src === 'number') ? src.toString() : src;
  if (srcText.length < hi.length)
    return src;
  const parts = srcText.split(new RegExp(`(${hi})`, 'gi'));  // if no matches, returns an array of the entire string
  return (parts.length > 1)
  ? <>{parts.filter(p => p).map((part, i) => 
        (part === hi)
        ? <span key={i} className='hi'>{part}</span>
        : part)}
    </>
  : src;
}

export const LabeledSwitch = ({enable, setEnable, children}:
  PropsWithChildren<{
    enable: boolean;
    setEnable: (enable: boolean) => void;
}>) =>
  <label>
    <Switch checked={enable} onChange={setEnable}
      {...cLo('group relative inline-flex h-5 w-10 flex-shrink-0 cursor-pointer items-center justify-center',
        'rounded-full focus:outline-none focus:ring-2 focus:ring-indigo-600 focus:ring-offset-2')}
    >
      <span className="sr-only">Use setting</span>
      <span aria-hidden="true" className="pointer-events-none absolute h-full w-full rounded-md bg-white" />
      <span aria-hidden="true"
        {...cLo(enable ? 'bg-indigo-600' : 'bg-gray-200',
          'pointer-events-none absolute mx-auto h-4 w-9 rounded-full',
          'transition-colors duration-200 ease-in-out')}
      />
      <span
        aria-hidden="true"
        {...cLo(enable ? 'translate-x-5' : 'translate-x-0',
          'pointer-events-none absolute left-0 inline-block h-5 w-5 transform rounded-full border',
          'border-gray-200 bg-white shadow ring-0 transition-transform duration-200 ease-in-out')}
      />
    </Switch>
    {children && <span>{children}</span>}
  </label>;

export function Alarm({setAlarm, children}:
  PropsWithChildren<{
  setAlarm: (ala: string) => void;
}>) {
  return (
    <div {...cLo(children ? 'block' : 'hidden', 'absolute right-3 bottom-1 w-96 mr-2 mb-4')}>
      <div className="rounded-md bg-red-100 p-4 border-2 border-red-100">
        <Transition
          show={!!children}
          enter="transform ease-out duration-300 transition"
          enterFrom="translate-y-2 opacity-0 sm:translate-y-0 sm:translate-x-2"
          enterTo="translate-y-0 opacity-100 sm:translate-x-0"
          leave="transition ease-in duration-100"
          leaveFrom="opacity-100"
          leaveTo="opacity-0"
        >
          <div className="flex">
            <div className="flex-shrink-0">
              <XCircleIcon className="h-5 w-5 text-red-400" aria-hidden="true" />
            </div>
            <div className="ml-3">
              <p className="text-sm font-medium text-red-800">{children}</p>
            </div>
            <div className="ml-auto pl-3">
              <div className="-mx-1.5 -my-1.5">
                <button type="button"
                  {...cLo('inline-flex rounded-md bg-red-50 p-1.5 text-red-500 hover:bg-red-100',
                    'focus:outline-none focus:ring-2 focus:ring-red-600 focus:ring-offset-2',
                    'focus:ring-offset-red-50')}
                  onClick={() => setAlarm('')}
                >
                  <span className="sr-only">Dismiss</span>
                  <XMarkIcon className="h-5 w-5 fill-red-500" aria-hidden="true" />
                </button>
              </div>
            </div>
          </div>
        </Transition>
      </div>
    </div>);
}

/**
 * Notification
 * notification message will be set as children.
 * setNoti callback is needed only to clean up the message.
 */
export function Noti({setNoti, children}:
  PropsWithChildren<{
  setNoti: (noti: string) => void;
}>) {
  // Global notification live region, render this permanently at the end of the document
  return (
    <div
      aria-live="assertive"
      {...cLo('pointer-events-none fixed inset-x-0 bottom-0 flex items-end px-4 py-6',
        'sm:items-start sm:p-6 z-10')}
    >
      <div className="flex w-full flex-col items-center space-y-4 sm:items-end">
        {/* Notification panel, dynamically insert this into the live region when it needs to be displayed */}
        <Transition
          show={!!children}
          enter="transform ease-out duration-300 transition"
          enterFrom="translate-y-2 opacity-0 sm:translate-y-0 sm:translate-x-2"
          enterTo="translate-y-0 opacity-100 sm:translate-x-0"
          leave="transition ease-in duration-100"
          leaveFrom="opacity-100"
          leaveTo="opacity-0"
        >
          <div {...cLo('pointer-events-auto w-full max-w-sm overflow-hidden rounded-lg bg-white',
            'shadow-lg ring-1 ring-black ring-opacity-5')}
          >
            <div className="p-4">
              <div className="flex items-start">
                <div className="flex-shrink-0">
                  <CheckCircleIconO className="h-6 w-6 text-green-400" aria-hidden="true" />
                </div>
                <div className="ml-3 w-0 flex-1 pt-0.5">
                  <p className="text-sm font-medium text-gray-900">{children}</p>
                  {/* <p className="mt-1 text-sm text-gray-500">【デモ版】ポップアップ通知です。</p> */}
                </div>
                <div className="ml-4 flex flex-shrink-0">
                  <button type="button"
                    {...cLo('inline-flex rounded-md bg-white text-gray-400 hover:text-gray-500',
                      'focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2')}
                    onClick={() => setNoti('')}
                  >
                    <span className="sr-only">Close</span>
                    <XMarkIcon className="h-5 w-5" aria-hidden="true" />
                  </button>
                </div>
              </div>
            </div>
          </div>
        </Transition>
      </div>
    </div>);
}

export interface ISlideOverParam {
  slideOn:    boolean;
  setSlideOn: (show: boolean) => void;
  title?:     string;
}
export function SlideOver({slideOn, setSlideOn, title, children}:
  PropsWithChildren<ISlideOverParam>
) {
  return (
    <Transition show={slideOn}>
      <Dialog className="relative z-30" onClose={setSlideOn}>
        <div className="fixed inset-0" />

        <div className="fixed inset-0 overflow-hidden">
          <div className="absolute inset-0 overflow-hidden">
            <div className="pointer-events-none fixed inset-y-0 right-0 flex max-w-full pl-10">
              <TransitionChild
                enter="transform transition ease-in-out duration-500 sm:duration-700"
                enterFrom="translate-x-full"
                enterTo="translate-x-0"
                leave="transform transition ease-in-out duration-500 sm:duration-700"
                leaveFrom="translate-x-0"
                leaveTo="translate-x-full"
              >
                <DialogPanel className="pointer-events-auto w-screen max-w-xl">
                  <div className="flex h-full flex-col overflow-y-scroll bg-white py-6 shadow-xl">
                    <div className="px-4 sm:px-6 bg-gray-300">
                      <div className="flex items-start justify-between">
                        <DialogTitle className="text-base font-semibold leading-6 text-gray-900">
                          {title}
                        </DialogTitle>
                        <div className="ml-3 flex h-7 items-center">
                          <button type="button"
                            {...cLo('relative rounded-md bg-white text-gray-400 hover:text-gray-500',
                              'focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2')}
                            onClick={() => setSlideOn(false)}
                          >
                            <span className="absolute -inset-2.5" />
                            <span className="sr-only">Close panel</span>
                            <XMarkIconO className="h-6 w-6" aria-hidden="true" />
                          </button>
                        </div>
                      </div>
                    </div>
                    <div className="relative mt-6 flex-1 px-4 sm:px-6">{children}</div>
                  </div>
                </DialogPanel>
              </TransitionChild>
            </div>
          </div>
        </div>
      </Dialog>
    </Transition>);
}

export interface IModalDlgParam {
  dlgOn:       boolean;
  setDlgOn:    (show: boolean) => void;
  onOkCancel?: (b: boolean) => void;  // callback with true on OK, or false on Cancel
  title?:      string;
  checkIcon?:  boolean;
}
export function ModalDlg({dlgOn, setDlgOn, onOkCancel, title, checkIcon, children}:
  PropsWithChildren<IModalDlgParam>
) {
  return (
    <Transition show={dlgOn}>
      <Dialog className="relative z-30" onClose={setDlgOn}>
        <TransitionChild
          enter="ease-out duration-300"
          enterFrom="opacity-0"
          enterTo="opacity-100"
          leave="ease-in duration-200"
          leaveFrom="opacity-100"
          leaveTo="opacity-0"
        >
          <div className="fixed inset-0 bg-gray-500 bg-opacity-75 transition-opacity" />
        </TransitionChild>

        <div className="fixed inset-0 z-10 w-screen overflow-y-auto">
          <div className="flex min-h-full items-end justify-center p-4 text-center sm:items-center sm:p-0">
            <TransitionChild
              enter="ease-out duration-300"
              enterFrom="opacity-0 translate-y-4 sm:translate-y-0 sm:scale-95"
              enterTo="opacity-100 translate-y-0 sm:scale-100"
              leave="ease-in duration-200"
              leaveFrom="opacity-100 translate-y-0 sm:scale-100"
              leaveTo="opacity-0 translate-y-4 sm:translate-y-0 sm:scale-95"
            >
              <DialogPanel {...cLo('relative transform overflow-hidden rounded-lg bg-white px-4 pb-4 pt-5',
                'text-left shadow-xl transition-all sm:my-8 sm:w-full sm:max-w-lg sm:p-6')}
              >
                <div>
                  <div {...cLo(checkIcon ? 'block' : 'hidden',
                    'mx-auto flex h-12 w-12 items-center justify-center rounded-full bg-green-100')}
                  >
                    <CheckIcon className="h-6 w-6 text-green-600" aria-hidden="true" />
                  </div>
                  <div className="mt-3">
                    <DialogTitle as="div"
                      {...cLo('w-full text-base font-semibold text-center leading-6',
                        'py-1 text-gray-900 bg-gray-300')}
                    >
                      {title}
                    </DialogTitle>
                    <div className="mt-2">{children}</div>
                  </div>
                </div>
                <div className="mt-5 sm:mt-6 sm:grid sm:grid-flow-row-dense sm:grid-cols-2 sm:gap-3">
                  <button type="button"
                    {...cLo('inline-flex w-full justify-center rounded-md bg-indigo-600 px-3 py-2 text-sm',
                      'font-semibold text-white shadow-sm hover:bg-indigo-500',
                      'focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2',
                      'focus-visible:outline-indigo-600 sm:col-start-2')}
                    onClick={() => { onOkCancel?.(true); setDlgOn(false);}}
                  >
                    OK
                  </button>
                  <button type="button"
                    {...cLo('mt-3 inline-flex w-full justify-center rounded-md bg-white px-3 py-2',
                      'text-sm font-semibold text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300',
                      'hover:bg-gray-50 sm:col-start-1 sm:mt-0')}
                    onClick={() => { onOkCancel?.(false); setDlgOn(false);}}
                    data-autofocus
                  >
                    キャンセル
                  </button>
                </div>
              </DialogPanel>
            </TransitionChild>
          </div>
        </div>
      </Dialog>
    </Transition>);
}

export const CheckV = ({checked, setChecked, className, children}: PropsWithChildren<{
  checked:    boolean;
  setChecked: (check: boolean) => void;
  className?: string;
}>) =>
  <div {...cLo(className, 'flex gap-1 items-center whitespace-nowrap')}>
    <Checkbox
      {...{checked}}
      onChange={setChecked}
      {...cLo('group block size-4 min-w-4 rounded border bg-white',
        'data-[checked]:bg-blue-500 hover:cursor-pointer')}
    >
        <svg className="stroke-white opacity-0 group-data-[checked]:opacity-100"
          viewBox="0 0 14 14" fill="none"
        >
          <path d="M3 8L6 11L11 3.5" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" />
        </svg>
    </Checkbox>
    {children}
  </div>;
    

// abstraction of timed messaging for Alarm, Noti, etc.
export const useTimedMsg = () => {
  const [msg, setMsg] = useState('');
  const setMsgMs = (text: string, duration: number) => {
    setMsg(text);
    setTimeout(() => setMsg(''), duration);
  }
  return ({msg, setMsg, setMsgMs});
}

export interface IDropdownMenuItem {
  label:      string;
  onMenuItem: (sel: number) => void;  // onClick event handler passing selected menu id
}
export function DropdownMenu({menu, sel, setSel}: {
  menu:   IDropdownMenuItem[];
  sel:    number;
  setSel: IDropdownMenuItem['onMenuItem'];
}) {
  return (
    <Menu>
      <MenuButton {...cLo('menu -ml-1 mr-1 p-2 inline-flex items-center',
        'bg-gray-200 border-r border-gray-500 text-sm/6 font-semibold focus:outline-none',
        'data-[hover]:bg-gray-300 data-[open]:bg-blue-300 data-[focus]:outline-1 data-[focus]:outline-white')}
      >
        {menu[sel].label}
        <ChevronDownIcon className="size-4" />
      </MenuButton>
      <MenuItems anchor="bottom start"
        className='z-30 bg-gray-200 p-2 text-sm rounded-md border border-gray-400 drop-shadow-md cursor-pointer'
      >
        {menu.map((m, s) =>
        <MenuItem key={m.label}>
          <a {...cLo('block py-0.5 data-[focus]:bg-blue-300', s === sel && 'font-bold')}
            onClick={() => {
              setSel(s);
              m.onMenuItem?.(s);
            }}
          >
            {m.label}
          </a>
        </MenuItem>)}
      </MenuItems>
    </Menu>);
}

export interface IRadioButtonItem {
  id:       string;
  label:    string;
  default?: boolean;
}
export const RadioButtons = ({choices, setChoice}: {
  choices:   IRadioButtonItem[];
  setChoice: (v: string) => void;
}) =>
  <fieldset>
    <div className="flex items-center gap-5">
      {choices.map(w => (
        <div key={w.id} className="flex items-center">
          <input type="radio"
            id={w.id}
            value={w.id}
            defaultChecked={w.default}
            onChange={ev => setChoice(ev.currentTarget.value)}
            className="h-4 w-4 border-gray-300 text-indigo-600 focus:ring-indigo-600 hover:cursor-pointer"
          />
          <label className="ml-1 block text-sm font-medium text-gray-900 leading-8">
            {w.label}
          </label>
        </div>))}
    </div>
  </fieldset>;

export const InputTextBtn = ({value, setValue, onClick}: {
  value:    string;
  setValue: (s: string) => void;
  onClick?: () => void;
}) => {
  return (
    <div className="relative my-1 flex items-center">
      <input type="text"
        name="inputtextk"
        id="inputtextk"
        {...{value}}
        onChange={ev => setValue(ev.currentTarget.value)}
        {...cLo('block w-full rounded-none rounded-l-md border-0 py-1.5 text-gray-900',
          'ring-1 ring-inset ring-gray-300 placeholder:text-gray-400',
          'focus:ring-2 focus:ring-inset focus:ring-indigo-600 sm:text-sm sm:leading-6')}
      />
      <button type="button"
          {...cLo('relative -ml-px inline-flex items-center gap-x-1.5 rounded-r-md',
          'px-3 py-2 text-sm font-semibold text-gray-900 whitespace-nowrap',
          'ring-1 ring-inset ring-gray-300 hover:bg-gray-50')}
        {...{onClick}}
      >
        参照
      </button>
    </div>);
}
