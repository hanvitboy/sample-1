/**
 * @file    search condition dialog ltp
 *          検索条件設定 長期作業計画
 * @version 0.1
 * @Date    2024/06/24
 * @author  TA_金秀
 */

import { useState, } from "react";
import { type IModalDlgParam, CheckV, InputTextBtn, ModalDlg, } from 'util/ux';
import { cLo, } from 'util/util';

export interface ISearchCond {
  chs:      boolean[];
  eqCat:    string;
  rgTmp:    string;
  setChs:   (b: boolean[]) => void;
  setEqCat: (s: string) => void;
  setRgTmp: (s: string) => void;
}

const CHECKS = [
  '自社', 'グループ会社', '外部企業',
  '対象', '非対称',
  '廃止', '休止',
  '廃止', '休止',
  '直営', '保守契約',
  '昼', '夜', '昼夜',  // 1,2,3
];

export const useSearchCond = () => {
  const [dlgOn, setDlgOn] = useState(false);
  const [chs,   setChs]   = useState<boolean[]>([...Array(CHECKS.length)].fill(false));
  const [eqCat, setEqCat] = useState('');     // 設備カテゴリ
  const [rgTmp, setRgTmp] = useState('');     // 定期検査ひな型名称

  return ({
    dlgOn, setDlgOn,
    chs,   setChs,
    eqCat, setEqCat,
    rgTmp, setRgTmp,
  });
}

export const SearchCondDlg = ({
  dlgOn, setDlgOn,
  chs,   setChs,
  eqCat, setEqCat,
  rgTmp, setRgTmp,
  onOkCancel,
}: IModalDlgParam & ISearchCond & { onOkCancel: (b: boolean) => void }) => {
  const initialize = () => setChs([...Array(CHECKS.length)].fill(false));
  const CheckSpread = ({st, ed}: { st: number; ed: number; }) =>
    <>
      {CHECKS.slice(st, ed).map((s, i) => {
        const j = st + i;
        return (
          <CheckV key={i} checked={chs[j]}
            setChecked={() => setChs([...chs.slice(0,j), true, ...chs.slice(j+1)])}
          >
            {s}
          </CheckV>);
      })}
    </>;

  const body = [
    {label: '実施主体',           cont: <CheckSpread st={0}  ed={3} />,},
    {label: '実施基準対象検査',   cont: <CheckSpread st={3}  ed={5} />,},
    {label: '廃止／休止',},
    {label: '・→検査設備台帳',    cont: <CheckSpread st={5}  ed={7} />,},
    {label: '・→検査台帳',        cont: <CheckSpread st={7}  ed={9} />,},
    {label: '直営／保守契約',     cont: <CheckSpread st={9}  ed={11} />,},
    {label: '作業時間帯',         cont: <CheckSpread st={11} ed={14} />,},
    {label: '設備カテゴリ',       cont:
      <InputTextBtn value={eqCat ?? ''}
        setValue={(s: string) => setEqCat(s)}
        onClick={() => alert('設備カテゴリ　コード入力　実装中')}
      />,},
    {label: '定期検査ひな型名称', cont: 
      <InputTextBtn value={rgTmp ?? ''}
        setValue={(s: string) => setRgTmp(s)}
        onClick={() => alert('敵検査ひな型名称　コード入力　実装中')}
      />,},
  ];
  return (
    <ModalDlg {...{dlgOn, setDlgOn, onOkCancel}} title='検索条件設定'>
      <div className="px-4 py-5 sm:px-0 sm:py-0">
        <dl className="space-y-8 sm:space-y-0 sm:divide-y sm:divide-gray-200">
          {body.map(r =>
            <div key={r.label} className="sm:flex sm:px-2 sm:py-2 leading-8">
              <dt className="text-sm font-medium text-gray-900 sm:w-40 sm:flex-shrink-0 lg:w-48">
                {r.label}
              </dt>
              <dd className="text-sm text-black sm:col-span-2 sm:ml-6 sm:mt-0 flex gap-3">
                {r.cont}
              </dd>
            </div>)}
        </dl>
        <div className='flex'>
          <button type="button"
            {...cLo('rounded bg-white px-2 py-1 text-sm font-semibold text-gray-900 shadow-sm',
              'ring-1 ring-inset ring-gray-300 hover:bg-gray-50')}
            onClick={initialize}
          >
            初期化
          </button>
        </div>
      </div>
    </ModalDlg>);
}
