/**
 * @file    REFMa 長期作業計画
 * @version 0.1
 * @Date    2024/06/25
 * @author  TA_金秀
 **/
import { useState, } from 'react';
import type { TDataLine, IDataMapper, } from 'util/loader';
import { xNULL, } from 'util/loader';
import { lZ, } from 'util/util';

export const selectD_plans: IDataMapper = (r) =>
[
  r[0],  // 検査ID
  // r[1],  // 所管区ID  - 既に所管区で絞った結果であるため不要
  r[2],  // 予定ID
  r[5],  // 実施予定月
  r[6],  // 作業時間帯
  r[10], // 許容期間_開始
  r[11], // 許容期間_終了
  r[12], // 初回承認_実施予定月
  r[13], // 初回承認_作業時間帯
].map(v => xNULL(v));

interface Plan {
  sid:  number;  // schedule id
  ym:   string;  // yyyy/mm      -> key for display
  wp:   number;  // work period
  p_st: string;  // plan start
  p_ed: string;  // plan end
  ym_f: string;  // yyyy/mm first approved
  wp_f: string;  // work period first approved
}
export interface IInspPlans {
  id: number;  // 検査ID
  ps: Plan[];  // plans
}

export const useSortedPlans = () => {
  const [aPlans, setAPlans]  = useState<IInspPlans[]>([]);
  const plansInsp = (id: number) => aPlans.find(el => el.id === id)?.ps;
  return ({
    setAPlans,
    plansInsp,
  });
}

// sort should be done in the side effect, not within the rendering
export const onPlansDataReady = (
  data:      TDataLine[],
  setAPlans: (aP: IInspPlans[]) => void,
) => {
  // sort raw data w.r.t. inspection id and schedule id
  console.log('Fetch end - plans:', performance.now(), data.length);
  data.sort((a: TDataLine, b: TDataLine) => (a[0] === b[0])
    ? Number(a[1]) - Number(b[1])    // 1st key
    : Number(a[0]) - Number(b[0]));  // 2nd key
  console.log('Sort end - plans:', performance.now());

  // group by inspection id, 
  const aps: IInspPlans[] = [];
  data.forEach(r => {
    const i = aps.findIndex(el => el.id === r[0]);
    const plan = {
      sid:  Number(r[1]),
      ym:   r[2]?.toString() || '',  // key for each month
      wp:   Number(r[3]),
      p_st: r[4]?.toString() || '',
      p_ed: r[5]?.toString() || '',
      ym_f: r[6]?.toString() || '',
      wp_f: r[7]?.toString() || '',
    };
    if (i >= 0) {
      aps[i].ps.push(plan);  // add to an existing inspection
    } else {
      aps.push({     // add a new inspection with the first plan data
        id: Number(r[0]),
        ps: [plan],
      });
    }
  });
  setAPlans(aps);
  return data;
}

export const getFiscalYrMo = (dt: Date = new Date()) => {  // 年度、月、
  const mo = dt.getMonth() + 1;
  return ({
    fy: dt.getFullYear() - (mo < 4 ? 1 : 0),
    mo,
  });
}

// (年度、index from 0) ⇒ '2024/12' format string
export const yyyy_mm = (fYr: number, i: number) =>
  `${fYr+Math.floor((i+3)/12)}/${lZ((i+3)%12+1)}`;
