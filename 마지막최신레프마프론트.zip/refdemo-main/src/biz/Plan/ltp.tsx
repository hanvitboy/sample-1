/**
 * @file    REFMa 長期作業計画
 * @version 0.1
 * @Date    2024/06/19
 * @author  TA_金秀
 **/
import { type PropsWithChildren, useState, } from 'react';
import { ST_STRING, ST_NUMERIC, } from 'compo/sorter';
import type { TDataLine, IDataMapper, } from 'util/loader';
import { xNULL, } from 'util/loader';
import { type ISlideOverParam, SlideOver, } from 'util/ux';
import { type IHeadInfo, JurisLine, } from 'biz/metro';

const SCREEN_NAME = '長期作業計画';

// select and transform
// 長期作業計画 LongTermPlan

export const headInfo: IHeadInfo[] = [  // no rowSpan
  { name:'検査ID',               sort:ST_NUMERIC, rs:2, },       // 1st
  // 既存画面
  { name:'組織区分',             sort:ST_STRING, rs:2, lv:2, },
  { name:'検査設備名',           sort:ST_STRING, rs:2, lv:2, },
  { name:'周期',                 sort:ST_STRING, rs:2,},
  { name:'作業コード',           sort:ST_STRING, rs:2, lv:3, },
  { name:'場所',                 sort:ST_STRING, rs:2,},
  { name:'実施主体',             sort:ST_STRING, rs:2, lv:3, },
  { name:'計画策定に関する備考', sort:ST_STRING, rs:2, lv:3, },
  // 追加項目
  { name:'検査補足名称',         sort:ST_STRING, rs:2, lv:4, },  // 9th
  { name:'補足',                 sort:ST_STRING, rs:2, lv:4, },
  { name:'承認に関する備考',     sort:ST_STRING, rs:2, lv:4, },
  { name:'補足(定期検査ひな型)', sort:ST_STRING, rs:2, lv:4, },
  { name:'補足(検査設備台帳型)', sort:ST_STRING, rs:2, lv:4, },
  { name:'変更理由',             sort:ST_STRING, rs:2, lv:4, },  // 14th
];

export const headClass = (c: number) =>
  headInfo[c].cls && {className: headInfo[c].cls};

// map csv raw data to display data
// SQLクエリ結果のcsvファイルから、行毎に画面表示に使う項目へ変換する処理の定義
export const selectD: IDataMapper = (r) =>
[
  r[2],   // 検査ID
  // 既存画面
  r[52],  // SK_組織区分
  r[47],  // T_検査名称
  r[60],  // B1_表示用基準期間
  r[103], // 作業コード名称
  r[77],  // KS_設置場所_計画表示用
  r[39],  // 実施主体名称
  r[17],  // 計画策定に関する備考
  // 追加項目
  r[4],   // 検査補足名称
  r[15],  // 補足
  r[18],  // 承認に関する備考
  r[50],  // T_補足
  r[90],  // KS_補足
  r[102], // K_変更理由
  // 既存検索 
  /*
  r[5],
  aprvStatus(r[33]),  // 状態
  r[0],
  r[1],
  r[35]+'・'+r[36],
  r[4],
  r[44]+'_'+r[46],
  r.slice(37,42).filter(x => x !== 'NULL' && x).join('-'),
  r[12] === 0 ? null : r[13]+'～'+r[14],  // 休止期間
  r[10] === 0 ? null : r[11],             // 廃止日
  r[21],
  r[48] === 'NULL' ? null : r[48],
  */
].map(v => xNULL(v));

// temporal
export const SearchConditions = ({
  fYrList, fYr, setFYr,
  periods, prd, setPrd,
  jurisId,
  children
}: {
    fYrList: number[];
    fYr:     number;
    setFYr:  (y: number) => void;
    periods: number[];
    prd:     number;
    setPrd:  (p: number) => void;
  } & PropsWithChildren<{jurisId: number;}>
) =>
  <div className='SearchConditions'>
    <span className='SCLabel'>検索条件</span>
    <div className='SCText'>
      年度：
      <select value={fYr} onChange={ev => setFYr(Number(ev.currentTarget.value))}>
        {fYrList.map((_op, k) => <option key={k}>{fYrList[k]}</option>)}
      </select>
      表示期間：
      <select value={prd+'年'} onChange={ev => setPrd(Number(ev.currentTarget.value[0]))}>
        {periods.map((_op, k) => <option key={k}>{periods[k]}年</option>)}
      </select>
      所管区変更日：2020/04/01 <JurisLine {...{jurisId}} />
    </div>
    {children}
  </div>;

// 詳細画面
export const Detail = ({body, id}: {
  body: TDataLine[], 
  id:   number,
}) => {
  const rec = body.find(r => r[0] === id);  // 検査ID
  return (rec
  ? <div className="px-4 py-5 sm:px-0 sm:py-0 border-2 border-indigo-500/30 rounded-xl">
      <dl className="space-y-8 sm:space-y-0 sm:divide-y sm:divide-gray-200">
      {rec.map((r, i) =>
        <div key={i} className="sm:flex sm:px-2 sm:py-2">
          <dt className="text-sm font-medium text-blue-900 sm:w-40 sm:flex-shrink-0 lg:w-48">
            {headInfo[i].name}
          </dt>
          <dd className="text-sm text-black sm:col-span-2 sm:ml-6 sm:mt-0">
            {r}
          </dd>
        </div>)}
      </dl>
    </div>
  : <div>該当する検査が見つかりません。</div>);
}

export const useDetailSlide = () => {
  const [slide,   setSlide]   = useState(0);     // active 検査設備ID
  const [slideOn, setSlideOn] = useState(false);
  const openDetailSlide = (id: typeof slide) => {
    setSlide(id);
    setSlideOn(true);
  }
  return ({
    openDetailSlide,
    slide,
    slideOn, setSlideOn,
  });
}

export const DetailSlide = ({slide, slideOn, setSlideOn, body}: {
  slide: number;
  body:  TDataLine[], 
} & ISlideOverParam) =>
  <SlideOver {...{slideOn, setSlideOn}} title={`${SCREEN_NAME}詳細`}>
    <Detail id={slide} {...{body}} />
  </SlideOver>;

