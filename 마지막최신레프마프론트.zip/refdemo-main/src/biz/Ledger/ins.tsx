/**
 * @file    REFMa 検査台帳
 * @version 0.1
 * @Date    2024/06/27
 * @author  TA_金秀
 **/
import { type PropsWithChildren, Fragment, useState, } from 'react';
import type { IDataMapper, TDataLine, } from 'util/loader';
import { xNULL, } from 'util/loader';
import { type IHeadInfo, aprvStatus, JurisLine, } from 'biz/metro';
import { HiTags, } from 'compo/search';
import { ST_STRING, ST_NUMERIC, } from 'compo/sorter';
import type { ISlideOverParam, IModalDlgParam, } from 'util/ux';
import { maruNum, SlideOver, ModalDlg, } from 'util/ux';

const SCREEN_NAME = '検査台帳';

// Inspection Equipment Header column attributes 検査設備台帳ヘッダーの属性定義
// Columns with id will be the search target
export const headSrc: IHeadInfo[][] = [
  [  // 表ヘッド、行毎
    {        name:'',                     rs:2, },  // 鉛筆アイコン
    { id:0,  name:'状態',                 rs:2, sort:ST_STRING,          cls: 'aprv', },
    { id:1,  name:'検査ID',           rs:2, sort:ST_NUMERIC, },
    { id:2,  name:'検査設備名',           rs:2, sort:ST_STRING,          cls: 'ieqName', },
    { id:3,  name:'設置場所',             rs:2, sort:ST_STRING, lv:3, },

    { id:4,  name:'設置場所(計画表示用)', rs:2, sort:ST_STRING, },
    { id:5,  name:'所管区',               rs:2, sort:ST_STRING, lv:3, cls: 'juris', },
    {        name:'設備カテゴリ',         cs:6,                 lv:2, },  // 上位ヘッダー
    { id:12, name:'休止期間',             rs:2, sort:ST_STRING, },
    { id:13, name:'廃止日',               rs:2, sort:ST_STRING, },

    { id:14, name:'最終更新日',           rs:2, sort:ST_STRING, },
    { id:15, name:'最終更新者',           rs:2, sort:ST_STRING, lv:3, },
    {        name:'',                     rs:2, },  // 削除アイコン
    {        name:'複写',                 rs:2, },
  ],
  [  // 2行目
    { id:6,  name:'組織区分', sort:ST_STRING, lv:2, cls: 'maruN filledMaru', },  // uppper colSpan should also be varied!
    { id:7,  name:'レベル1',  sort:ST_STRING, lv:2, cls: 'maruN', },
    { id:8,  name:'レベル2',  sort:ST_STRING, lv:2, cls: 'maruN', },
    { id:9,  name:'レベル3',  sort:ST_STRING, lv:2, cls: 'maruN', },
    { id:10, name:'レベル4',  sort:ST_STRING, lv:2, cls: 'maruN', },
    { id:11, name:'レベル5',  sort:ST_STRING, lv:2, cls: 'maruN', },
  ]];
// Display level logic moved to CSS for better performance (fewer changes in DOM per rendering) 2024/05/40

export const headInfo = [  // Header from Body index map (To get the header attribute from the body index)
  headSrc[0][1], headSrc[0][2], headSrc[0][3], headSrc[0][4], headSrc[0][5],
  headSrc[0][6], headSrc[1][0], headSrc[1][1], headSrc[1][2], headSrc[1][3],
  headSrc[1][4], headSrc[1][5], headSrc[0][8], headSrc[0][9], headSrc[0][10],
  headSrc[0][11],
];

export const headClass = (c: number) =>
  headInfo[c].cls && {className: headInfo[c].cls};

// map csv raw data to display data
// SQLクエリ結果のcsvファイルから、行毎に画面表示に使う項目へ変換する処理の定義
export const selectD: IDataMapper = (r) =>  // functional
[
  aprvStatus(r[1]),  // 状態
  Number(r[0]),
  r[2],
  r[3],
  r[4],
  r[8],
  r[9],
  r[38],
  r[39],
  r[40],
  r[41],
  r[42],
  r[12] === 0 ? null : r[13]+'～'+r[14],  // 休止期間
  r[10] === 0 ? null : r[11],             // 廃止日
  r[21],
  r[48],
].map(v => xNULL(v));

export const markupD : IDataMapper = (r) =>
[
  r[0], r[1],                       // or ...slice(0,2), slice(from, end-not included)
  (r[2] as string)?.split('_')[0],  // 検査設備名 _設置場所(計画表示用)_所管区 省略
  // (r[2] as string)?.split('_')?.slice(0,-2)?.join('_'),  // 検査設備名 _設置場所(計画表示用)_所管区 省略
  r[3], r[4],
  (r[5] as string)?.split('_')[1],  // 鉄道本部電気部電機区_ 省略
  ...r.slice(6)

];

// Markup make up 化粧
// 特別に化粧が必要な列のmarkupを定義する
export function MarkupText(src?: string0|number, cls?: string, tags?: string[]) {
  if (!src)
    return null;
  const srcText = (typeof src === 'number') ? src.toString() : src;
  if (cls) {
    if (cls.includes('insName')) {  // 検査設備名
      const del = '-';
      const part = srcText.split(del);
      if (part)
        return <>{part.map((p, k) =>
          <Fragment key={k}>{k > 0 && del}
            <span data-n={k}>{HiTags(tags, p)}</span>
          </Fragment>)}
        </>;
    } else if (cls.includes('maruN')) {
      const mn = maruNum(srcText, cls.includes('filledMaru') ? 1 : 0);
      if (mn)
        return <><span data-n={0}>{mn.num}</span>{HiTags(tags, mn.text)}</>;
    }
  }
  return HiTags(tags, srcText);
}

export const SearchConditions = ({jurisId, children}: PropsWithChildren<{ jurisId: number; }>) =>
  <div className='SearchConditions'>
    <span className='SCLabel'>検索条件</span>
    <span className='SCText'>所管区変更日：2020/04/01 <JurisLine {...{jurisId}} /></span>
    {children}
  </div>;

// 詳細画面
export const Detail = ({body, id}: {
  body: TDataLine[], 
  id:   number,
}) => {
  const rec = body.find(r => r[1] === id);  // 検査設備ID
  return (rec
  ? <div className="px-4 py-5 sm:px-0 sm:py-0 border-2 border-indigo-500/30 rounded-xl">
      <dl className="space-y-8 sm:space-y-0 sm:divide-y sm:divide-gray-200">
      {rec.map((r, i) =>
        <div key={i} className="sm:flex sm:px-2 sm:py-2">
          <dt className="text-sm font-medium text-blue-900 sm:w-40 sm:flex-shrink-0 lg:w-48">
            {headInfo[i].name}
          </dt>
          <dd className="text-sm text-black sm:col-span-2 sm:ml-6 sm:mt-0">
            {r}
          </dd>
        </div>)}
      </dl>
    </div>
  : <div>{`該当する${SCREEN_NAME}が見つかりません。`}</div>);
}

export const useDetailSlide = () => {
  const [slide,   setSlide]   = useState(0);     // active 検査設備ID
  const [slideOn, setSlideOn] = useState(false);
  const openDetailSlide = (id: typeof slide) => {
    setSlide(id);
    setSlideOn(true);
  }
  return ({
    openDetailSlide,
    slide,
    slideOn, setSlideOn,
  });
}

// 詳細画面
export const DetailSlide = ({slide, slideOn, setSlideOn, body}: {
  slide: number;
  body:  TDataLine[]; 
} & ISlideOverParam) =>
  <SlideOver {...{slideOn, setSlideOn}} title={`${SCREEN_NAME}詳細`}>
    <Detail id={slide} {...{body}} />
  </SlideOver>;

export const useDetailDlg = () => {
  const [dlg,   setDlg]     = useState(0);     // active 検査設備ID
  const [dlgOn, setDlgOn]   = useState(false);
  const openDetailDlg = (id: typeof dlg) => {
    setDlg(id);
    setDlgOn(true);
  }
  return ({
    openDetailDlg,
    dlg,
    dlgOn, setDlgOn,
  });
}

export const DetailDlg = ({dlg, dlgOn, setDlgOn, body}: {
  dlg:  number;
  body: TDataLine[];
} & IModalDlgParam) =>
  <ModalDlg  {...{dlgOn, setDlgOn}} title={`${SCREEN_NAME}編集`}>
    <Detail id={dlg} {...{body}} />
  </ModalDlg>;
