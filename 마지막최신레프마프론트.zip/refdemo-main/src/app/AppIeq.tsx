/**
 * @file    REFMa 検査設備一覧画面、MVC化に伴う画面側の実験
 * @version 1.1.0
 * @Date    2024/05/29
 * @author  TA_金秀
 * 2024/06/18 JSON → CSV、Object → Array of items
 */
import { useState, Suspense, } from 'react';
import { type IDropdownMenuItem, LabeledSwitch, useTimedMsg, Alarm, Noti, CheckV, } from 'util/ux';
import { Resizable, } from 'util/resizable';
import { useLoadParseData, } from 'util/loader';
import { useSearch, SearchInput, HiTags, } from 'compo/search';
import { useSorter, SpanSort, } from 'compo/sorter';
import { usePager, Pager, } from 'compo/pager';
import { useDispLv, DispLv, } from 'compo/displv';
import { JurisCombobox, nextJuris, useJuris, bizUrls, aprvId,
  REFMaIcon,
  REFMaBtn,
  REFMaBtnDownload,
  REFMaBtnUpload,
  REFMaBtnUpdate,
  REFMaBtnDispUpdate,
} from 'biz/metro';
import {
  selectD, markupD, headInfo, headSrc, MarkupText, headClass,
  useDetailSlide, DetailSlide,
  useDetailDlg, DetailDlg,
  SearchConditions,
} from 'biz/Ledger/ieq';
import 'styles/App.css';

function AppIeq() {
  const dispLevels = ['1','2','3'];  // 表示レベル(大きいほど細かい項目まで表示)
  const rowsPP = [10,20,50,100,200,500,1000,2000];  // rows per page selection list
  const onMenuItem: IDropdownMenuItem['onMenuItem'] = (s) => {
    alert('実装中 search scope:' + menu[s].label);
  }
  const menu: IDropdownMenuItem[] = [  // target scope
    {label:'すべて',    onMenuItem,},
    {label:'表示項目',  onMenuItem,},
    {label:'条件設定▷', onMenuItem,},
  ];
  // states
  // refactoring: to reduce rendering later change with ... and localize rendering of search and <input>
  const [markup,  setMarkup]  = useState(false); // turn on/off markup text
  const [reload,  setReload]  = useState(1);     // fetch count to force reload
  const [fetchTs, setFetchTs] = useState(new Date());  // timestamp
  const [throtle, setThrotle] = useState(true);  // 通信遅延効果simulation 有り／無し
  const {
    msg:      alarm,
    setMsg:   setAlarm,
    setMsgMs: setAlarmMs,
  } = useTimedMsg();
  const {
    msg:      noti,
    setMsg:   setNoti,
    setMsgMs: setNotiMs,
  } = useTimedMsg();
  const {openDetailSlide, ...detSlide} = useDetailSlide();
  const {openDetailDlg,   ...detDlg}   = useDetailDlg();

  const onFetchStart = (ts: Date) => {  // callback on fetch start
    setFetchTs(ts);
    setAlarm(`データ受信中 ${ts.toLocaleString()}`);
  }
  //************************************************************************************
  const {juris, setJuris} = useJuris();                             // 1. 所管区選択
  const {bodyRaw} = useLoadParseData(                               // 2. データロード
    reload,                     // fetch reload count
    bizUrls.Ieq(juris.id),      // url
    selectD,                    // select: 使用する列の選択+変換
    throtle ? 1000 : 0,         // delay(ms) effect
    undefined,                  // onDataReady
    setAlarm,                   // onError
    onFetchStart,               // onStart
    () => setAlarm(''),         // onEnd
  );
  // データ加工処理 rules for display / markup - run for each render
  const mkup = markup && bodyRaw.length                             // 3. データ加工 markup
    ? bodyRaw.map(r => markupD(r))
    : bodyRaw;
  const {fRes, ...srchR}      = useSearch(menu, mkup);              // 4. 検索
  const sortR                 = useSorter(headInfo, fRes);          // 5. ソート
  const {fResPaged, ...pageR} = usePager(fRes, rowsPP[3], rowsPP);  // 6. ページング
  const {dispLv, ...dispR}    = useDispLv(dispLevels);              // 7. 表示レベル
  //************************************************************************************
  // console.log(tags);  // check rendering occurrences w.r.t. the user key inputs
  // fRes.forEach(r => r.forEach(c => HiTags(tags, c)));

  // const show = (level: number|undefined) => !level || (level <= Number(dispLv));

  // [...Array(maxPage).keys()] ⇒ 0..(maxPage-1)
  // .filter(p => (maxPage <= 20) ? p : (p <= 11 || p === page || p >= (maxPage-10)))
  // .map(p => (maxPage > 20 && p === 11) 
  return (
    <div className='spa_demo ieq'>
      <SearchConditions jurisId={juris.id}>
        <JurisCombobox {...{juris, setJuris}} />
        <REFMaBtnDispUpdate {...{fetchTs, reload}} onClick={() => setReload(reload + 1)} />
        <CheckV checked={throtle} setChecked={setThrotle}>遅延</CheckV>
      </SearchConditions>
      <div className='SControls top'>
        <REFMaBtn className='navigate-search'
          onClick={() => setNotiMs(noti ? '' : '検索実装中', 3000)}
        >
          検索
        </REFMaBtn>
        <REFMaBtnDownload onClick={() => setNotiMs(noti ? '' : '通知試験中、デモ用です。', 3000)} />
        <REFMaBtnUpload   onClick={() => setAlarmMs(alarm ? '' : 'アラート試験中', 3000)} />
        <REFMaBtnUpdate   onClick={() => setJuris(nextJuris(juris.id))} />
        <SearchInput {...srchR}>
          <LabeledSwitch enable={markup} setEnable={setMarkup}>縮約</LabeledSwitch>
        </SearchInput>
      </div>
      <Pager {...pageR}>
        <DispLv {...{dispLv}} {...dispR} />
      </Pager>
      <Suspense fallback={<p className='loading'>Loading ... </p>}>
      {bodyRaw.length
      ? <table className={'ieq lv' + dispLv}>
          <thead>
          {headSrc.map((rows, r) =>
            <tr key={r}>
            {rows.map((hc, c) =>
              <Resizable key={c}>
              {({ref}) => (
                <th
                  data-lv={hc.lv || '1'}
                  {...(hc.rs && {rowSpan: hc.rs})}
                  {...(hc.cs && {colSpan: hc.cs})}
                >
                  {hc.name}
                  {hc.sort && <SpanSort c={hc.id} {...sortR} />}
                  <span className='resizer' {...{ref}} />
                </th>)}
              </Resizable>)}
            </tr>)}
          </thead>
          <tbody>
          {fResPaged.map(rec =>
            <tr key={rec[1]}>
              <td>
                <REFMaIcon action='edit'
                    onClick={() => openDetailDlg(rec[1] as number)}
                />
              </td>
              {rec.map((col, i) =>
                <td key={i} {...headClass(i)}
                  {...((i === 0) && {
                    'data-aprv': aprvId(col),
                    onClick: () => openDetailSlide(rec[1] as number)
                  })}
                >
                  {markup
                  ? MarkupText(col, headInfo[i].cls, srchR.hi ? srchR.tags : undefined)
                  : srchR.hi ? HiTags(srchR.tags, col) : col}
                </td>)}
              <td><REFMaIcon action='delete' /></td>
              <td><REFMaIcon action='copy'   /></td>
            </tr>)}
          </tbody>
        </table>
      : null}
      </Suspense>
      <div className='SControls bottom'>
        <REFMaBtn onClick={() => {
            srchR.setTags(['渋谷駅','外苑前','配線','新橋','表参道','青山','ケーブル']);
            setAlarmMs('デモ用の検索キーワード自動入力', 3000);
          }}
        >
          追加
        </REFMaBtn>
      </div>
      {/* Messaging */}
      <DetailSlide body={fRes} {...detSlide} />
      <DetailDlg   body={fRes} {...detDlg} />
      <Noti  {...{setNoti}}>{noti}</Noti>
      <Alarm {...{setAlarm}}>{alarm}</Alarm>
    </div>
  );
}
// ? fRes.filter((_, r) => r >= (page - 1)*rowsPage && r < page*rowsPage)

export default AppIeq;

/*
  const TH = ({rowSpan, colSpan, children}: PropsWithChildren<{
    rowSpan?: number;
    colSpan?: number; 
  }>) =>
    <th {...(rowSpan && {rowSpan})} {...(colSpan && {colSpan})} onClick={() => alert({children})}>{children}</th>;
  
  const TD = ({children}: PropsWithChildren) => <td>{children}</td>;
    children
    ? <td>{HighlightText(children.toLocaleString(), search)}</td>
    : <td></td>;
*/
