/**
 * @file    REFMa Final Demo 長期作業計画表 絞り込み検索
 * @version 0.1
 * @Date    2024/06/17
 * @author  TA_金秀
 *
 * TODO: Get ref of DropdownMenu, then restore the state on cancel with 条件設定popup
 * TODO: LTP plans should be displayed on the CSS grid. Using TABLE temporarily.
 **/
import { useState, Suspense, } from 'react';
import { type IDropdownMenuItem, useTimedMsg, Alarm, Noti, CheckV, ModalDlg, } from 'util/ux';
import { useSearch, SearchInput, HiTags, } from 'compo/search';
import { useSorter, SpanSort, } from 'compo/sorter';
import { Pager, usePager, } from 'compo/pager';
import { DispLv, useDispLv, } from 'compo/displv';
import { Resizable, } from 'util/resizable';
import { useLoadParseData, } from 'util/loader';
import { JurisCombobox, nextJuris, bizUrls, useJuris,
  REFMaBtn, REFMaBtnDispUpdate, wrkPrd,
} from 'biz/metro';
import { headInfo, headClass, selectD,
  useDetailSlide, DetailSlide, SearchConditions,
} from 'biz/Plan/ltp';
import { selectD_plans, useSortedPlans, onPlansDataReady,
  getFiscalYrMo, yyyy_mm,
} from 'biz/Plan/ltp_plans';
import { useSearchCond, SearchCondDlg, } from 'biz/Plan/scond_ltp';
import { cLo, } from 'util/util';
import { Tooltip, } from 'react-tooltip';
import 'styles/App.css';

const ArrowL = () =>
  <svg
    className='aL w-6 h-6 text-blue-700' aria-hidden='true' xmlns='http://www.w3.org/2000/svg'
    fill='none' viewBox='0 0 24 24'
  >
    <path
      stroke='currentColor'
      strokeLinecap='round'
      strokeWidth='1.5'
      d='M6.75 15.75 3 12m0 0 3.75-3.75M3 12h18'
    />
  </svg>;

const ArrowR = () =>
  <svg
    className='aR w-6 h-6 text-red-700' aria-hidden='true' xmlns='http://www.w3.org/2000/svg'
    fill='none' viewBox='0 0 24 24'
  >
    <path
      stroke='currentColor'
      strokeLinecap='round'
      strokeWidth='1.5'
      d='M17.25 8.25 21 12m0 0-3.75 3.75M21 12H3'
    />
  </svg>;

function AppLtp() {
  const dispLevels = ['1','2','3','4'];
  const rowsPP = [50,100,200,300,400,500,1000];
  const fYrList = [...Array(10).keys()].map(i => 2020+i);
  const now = getFiscalYrMo();                    // [今年度、今月]
  const [fYr,     setFYr]     = useState(now.fy); // fiscal display year 表示年度
  const periods = [1,3,7];                         // 最長7年間
  const [prd,     setPrd]     = useState(periods[1]);
  const [reload,  setReload]  = useState(1);      // fetch count to force reload
  const [fetchTs, setFetchTs] = useState(new Date());  // timestamp
  const [throtle, setThrotle] = useState(true);   // 遅延効果
  const [iniAprv, setIniAprv] = useState(false);  // 初回承認情報表示
  const [dlgOn,   setDlgOn]   = useState(false);  // 初回承認情報表示
  const [sScope,  setSScope]  = useState(0);      // set search scope
  const onMenuItem: IDropdownMenuItem['onMenuItem'] = (s) => {  // 検索スコープ
    if (s === menu.length-1) {  // 条件設定
      sC.setDlgOn(true);
    } else if (sScope !== s) {
      setSScope(s);
      console.log('search scope:', menu[s].label);
    }
  }
  const menu: IDropdownMenuItem[] = [  // target scope
    {label:'すべて',               onMenuItem,},
    {label:'表示項目',             onMenuItem,},
    {label:'作業コード',           onMenuItem,},
    {label:'計画策定に関する備考', onMenuItem,},
    {label:'条件設定▷',            onMenuItem,}
  ];
  const sC = useSearchCond();  // sC.cond
  const {
    msg:      alarm,
    setMsg:   setAlarm,
    setMsgMs: setAlarmMs,
  } = useTimedMsg();
  const {
    msg:      noti,
    setMsg:   setNoti,
    setMsgMs: setNotiMs,
  } = useTimedMsg();
  const {openDetailSlide, ...detail} = useDetailSlide();

  const onFetchStart = (ts: Date) => {  // callback on fetch start
    setFetchTs(ts);
    setAlarm(`データ受信中 ${ts.toLocaleString()}`);
  }
  //************************************************************************************
  const {juris, setJuris} = useJuris();                             // 1. 所管区選択
  // rendering毎にデータ変換処理を行うことは負荷が掛かるため、
  // 最初データロード時にデータ変換処理を済ませておく。
  const {bodyRaw} = useLoadParseData(                               // 2. データロード
    reload,                     // fetch reload count
    bizUrls.LtpInsp(juris.id),  // url
    selectD,                    // select: 使用する列の選択+変換
    throtle ? 1500 : 0,         // delay ms
    undefined,                  // onDataReady
    setAlarm,                   // onError callback
    onFetchStart,               // onStart
    () => setAlarm(''),         // onEnd
  );
  // no markup                                                      // 3. データ加工 markup
  const {fRes, ...srchR}      = useSearch(menu, bodyRaw);           // 4. 検索
  const sortR                 = useSorter(headInfo, fRes);          // 5. ソート
  const {fResPaged, ...pageR} = usePager(fRes, rowsPP[1], rowsPP);  // 6. ページング
  const {dispLv, ...dispR}    = useDispLv(dispLevels, '3');         // 7. 表示レベル 
  //************************************************************************************

  const sPs = useSortedPlans(); // for onDataReady 予実データのロード後の加工処理

  const {bodyRaw: planDB} = useLoadParseData(                               // 2. データロード
    reload,                     // fetch reload count
    bizUrls.LtpPlans(juris.id), // url
    selectD_plans,              // select: 使用する列の選択+変換
    0,                          // delay ms
    data => onPlansDataReady(data, sPs.setAPlans),  // onDataReady
    setAlarm,                   // onError callback
    () => console.log('Fetch start - plans:', performance.now()),              // onStart
    () => console.log('Fetch end - plans:', performance.now(), planDB.length), // onEnd
  );

  const REFMaButtons: {label: string; cls?: string; on?: () => void;}[] = [
    {label:'検索',           cls:'navigate-search', on: () => sC.setDlgOn(true), },
    {label:'編集',           cls:'navigate-save',   on: () => setNotiMs(noti ? '' : '編集', 3000),},
    {label:'計画更新',       cls:'aspNetDisabled'},
    {label:'承認依頼',       cls:'navigate-save aspNetDisabled',},
    {label:'承認依頼取消',   cls:'aspNetDisabled'},
    {label:'承認関連',       on: () => setJuris(nextJuris(juris.id)),},
    {label:'長期作業計画表', on: () => setNotiMs(noti ? '' : '長期作業計画表', 3000), },
    {label:'変更履歴',       on: () => setDlgOn(true),},
  ];

  const arrYr = [...Array(prd   ).keys()].map(i => fYr + i);          // year list: period 1, 3, 7 years
  const arrMo = [...Array(prd*12).keys()].map(i => yyyy_mm(fYr, i));  // month list
  const idMoNow = (now.fy - fYr) * 12 + (now.mo - 4);  // this month's index in arrMo (can be negative!)

  // Array.prototype.slice(start, end)
  // <span className='col-id'>{i}</span>{c}</th>
  return (
    <div className='spa_demo ltp'>
      <SearchConditions jurisId={juris.id} {...{fYrList, fYr, setFYr, periods, prd, setPrd}}>
        <JurisCombobox {...{juris, setJuris}} />
        <REFMaBtnDispUpdate {...{fetchTs, reload}} onClick={() => setReload(reload + 1)} />
        <CheckV checked={throtle} setChecked={setThrotle}>遅延</CheckV>
      </SearchConditions>
      <div className='SControls top'>
        {REFMaButtons.map(m =>
          <REFMaBtn key={m.label}
            {...(m.cls && {className: m.cls})}
            {...(m.on
                ? {onClick: m.on}
                : {onClick: () => setNotiMs(m.label, 3000)})}
          >
            {m.label}
          </REFMaBtn>)}
        <div className='text-xs flex items-center gap-0.5'>
          <CheckV checked={iniAprv}
            setChecked={() => {
              const nextIniAprv = !iniAprv;
              setNotiMs(`初回承認情報表示 ${nextIniAprv ? 'する' : 'しない'}`, 5000);
              setIniAprv(!iniAprv);
            }}
          />
          初回承認情報表示
        </div>
      </div>
      <SearchInput {...srchR}>
      </SearchInput>
      <Pager {...pageR}>
        <DispLv {...{dispLv}} {...dispR} />
        {/* <REFMaBtn className='aspNetDisabled'>一覧出力</REFMaBtn> */}
      </Pager>
      <Suspense fallback={<h1>Loading...</h1>}>
      {bodyRaw.length && planDB.length
      ? <table className={'ltp lv' + dispLv}>
          <thead>
            <tr>
            {headInfo.map((hc, c) =>
              <Resizable key={c}>
              {({ref}) =>
                <th
                  data-lv={hc.lv || '1'}
                  {...(hc.rs && {rowSpan: hc.rs})}
                  {...(hc.cs && {colSpan: hc.cs})}
                >
                  {hc.name}
                  {hc.sort && <SpanSort {...{c}} {...sortR} />}
                  <span className='resizer' {...{ref}} />
                </th>}
              </Resizable>)}
              {/* 予実データ*/}
              {arrYr.map((y, i) =>
                <th key={i} colSpan={12}
                  {...cLo('yr',
                      y === fYr && 'now',
                      y <= now.fy && 'aprvd')}
                >
                  {y}
                </th>)}
            </tr>
            <tr>
              {arrMo.map((m, i) =>
                <th key={i} rowSpan={2}
                  {...cLo('mo', i === idMoNow && 'now')}
                >
                  {m.slice(-2)}
                </th>)}
            </tr>
          </thead>
          <tbody>
          {fResPaged.map(rec => {
            const insp = Number(rec[0]); 
            const plns = sPs.plansInsp(insp);
            return (
              <tr key={insp}>
              {rec.map((col, i) =>
                <td key={i} {...headClass(i)}
                  {...((i === 0) && { onClick: () => openDetailSlide(insp) })}
                >
                  {srchR.hi ? HiTags(srchR.tags, col) : col}
                </td>)}
              {/* 予実データ*/}
              {arrMo.map((ym, i) => {
                const p = plns?.find(el => el.ym === ym);
                return ( 
                  <td key={i} {...(p && {'data-wp': p.wp})}>
                    {p &&
                    <a
                      data-tooltip-id='ltp-tt'
                      data-tooltip-content={`予定ID:${p.sid} ${p.p_st}～${p.p_ed} ${wrkPrd[p.wp].text}`}
                    >
                      <img src={wrkPrd[p.wp].ico} className='png' />
                      <ArrowL />
                      <ArrowR />
                    </a>}
                  </td>);})}
              </tr>)}
          )}
          </tbody>
        </table>
      : null}
      </Suspense>
      <div className='SControls bottom'>
        <REFMaBtn onClick={() => {
            srchR.setTags(['絶縁抵抗','渋谷駅','PED01','PPA33','トンネル','検査基準日平準化','ケーブル']);
            setAlarmMs('デモ用の検索キーワード自動入力', 3000);
          }}
        >
         検索テスト 
        </REFMaBtn>
      </div>
      {/* Messaging */}
      <SearchCondDlg {...sC}
        onOkCancel={ (b: boolean) => setSScope(b ? menu.length-1 : sScope) }
      />
      <DetailSlide body={fRes} {...detail} />
      <ModalDlg {...{dlgOn, setDlgOn}} title='変更履歴'>
        {[
          {name:'検索scope',          val:menu[sScope].label},
          {name:'検索条件',           val:sC.chs.map(c => c ? '1' : '0')},
          {name:'設備カテゴリ',       val:sC.eqCat},
          {name:'定期検査ひな型名称', val:sC.rgTmp},
        ].map(r =>
          <div key={r.name} className='flex'>
            <dt className='w-48 font-bold'>{r.name}</dt>
            <dd className='w-48'>{r.val}</dd>
          </div>)}
      </ModalDlg>
      <Noti {...{setNoti}}>{noti}</Noti>
      <Alarm {...{setAlarm}}>{alarm}</Alarm>
      <Tooltip id='ltp-tt' />
    </div>
  );
}

export default AppLtp;
