/**
 * @file    REFMaデモ版
 * @version 1.0.0
 * @Date    2024/06/19
 * @author  TA_金秀
 * - 複数画面の統合：HTMLのid="spa_id" 
 */

/*
// LTPSPAPage.cshtml
<head>
    <script id="spa_id" type="application/json">{"id":"ltp"}</script>
    <script type="module" crossorigin src="~/Content/demo/spa.js"></script>
    <link rel="stylesheet" crossorigin href="~/Content/demo/spa.css">
    ...
</head>
<div id="root"></div>
*/

import React from 'react';
import ReactDOM from 'react-dom/client';
import { DEBUG, } from 'util/util';
import AppIeq from 'app/AppIeq.tsx';
import AppIns from 'app/AppIns.tsx';
import AppLtp from 'app/AppLtp.tsx';
import Help from 'app/help.tsx';
import 'styles/index.css';
import 'react-tooltip/dist/react-tooltip.css';

const text = document.getElementById('spa_id')?.textContent;  // should be set in the embedding HTML
let spa_id = text ? JSON.parse(text)?.id  : '';
if (DEBUG) {
  const qP = new URLSearchParams(window.location.search);
  spa_id = qP.get('id');  // url?id=ltp
}

console.log('spa_id=', spa_id);

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    {(spa_id === 'ieq') && <AppIeq />}
    {(spa_id === 'ins') && <AppIns />}
    {(spa_id === 'ltp') && <AppLtp />}
    {(!spa_id) && <Help />}
  </React.StrictMode>,
);

/*
 * Lazy loadを使うと、distファイルが分散されてdeployが煩わしいので、デモ版では使わない。
const AppIeq = lazy(() => import('./AppIeq.tsx'));
const AppLtp = lazy(() => import('./AppLtp.tsx'));
const Loading = () => <h2>Loading main module...</h2>;

    {(spa_id === 'ieq') && <Suspense fallback={<Loading />}><AppIeq /></Suspense>}
    {(spa_id === 'ltp') && <Suspense fallback={<Loading />}><AppLtp /></Suspense>}
*/
