# REFMa (Railway Electrical Facilities Maintenance Management System) 鉄道電気設備保守管理システム フロントエンド化デモ
### 2024年（令6）6月

This template provides a minimal setup to get React working in Vite with HMR and some ESLint rules.

Currently, two official plugins are available:

- [@vitejs/plugin-react](https://github.com/vitejs/vite-plugin-react/blob/main/packages/plugin-react/README.md) uses [Babel](https://babeljs.io/) for Fast Refresh
- [@vitejs/plugin-react-swc](https://github.com/vitejs/vite-plugin-react-swc) uses [SWC](https://swc.rs/) for Fast Refresh

## Expanding the ESLint configuration

If you are developing a production application, we recommend updating the configuration to enable type aware lint rules:

- Configure the top-level `parserOptions` property like this:

```js
export default {
  // other rules...
  parserOptions: {
    ecmaVersion: 'latest',
    sourceType: 'module',
    project: ['./tsconfig.json', './tsconfig.node.json'],
    tsconfigRootDir: __dirname,
  },
}
```

- Replace `plugin:@typescript-eslint/recommended` to `plugin:@typescript-eslint/recommended-type-checked` or `plugin:@typescript-eslint/strict-type-checked`
- Optionally add `plugin:@typescript-eslint/stylistic-type-checked`
- Install [eslint-plugin-react](https://github.com/jsx-eslint/eslint-plugin-react) and add `plugin:react/recommended` & `plugin:react/jsx-runtime` to the `extends` list

### ASP.NET Web FormsのMVC化、ASP.NET Coreとの共存関係調査 2024/05/17(金)～24(金)
### 『検査設備台帳』SPA(Single Page App)版デモ2024/05/27(月)～06/12(水)
1. 列ソート
2. 絞り込み検索、ハイライト
3. 表示レベル
4. ページング
5. 列幅調整
6. markup、縮約
7. マルチ検索語
8. ポップアップ、スライド子画面

### 『長期作業計画表』SPA版デモ 2024/06/13(木)～/26(水)

1. SQLクエリ結果のCSVデータをHTTP/GETで受信、内部で画面表示用に変換
  - 長期作業計画検査一覧クエリ(SelectInspectionDataQuery.sql)
  - 予実データ１(SelectPrePlanDateDataQuery.sql)
  - 予実データ２(SelectPlanDateDataQuery.sql)
  - マスタ：所管区、設備カテゴリ、定期ひな型

2. 絞り込み検索、マルチ検索語
　- 画面表示項目(計画策定に関する備考等)＋非表示項目（補足、備考、変更履歴等）
  - ターゲット設定ボタン付きの検索語入力コントロール

3. ソート、列幅調整、ページング
　- 『検査設備台帳』SPA版同等の機能、通信を介さず迅速に画面更新が行われること

4. 「検索条件設定」ポップアップ
  - 選択項目（実施主体、実施基準対象検査、廃止／休止、直営／保守契約、作業時間帯）

5. 列固定ON/OFF、予実データ(年間計画)パートの拡張表示

※  予実データのSVGアイコン表示
  - 0.5か月周期
  - 許容期間
  - 実施予定月の移動処理
  - Tooltip

※  コード入力補助ポップアップ
  - 設備カテゴリ、定期検査ひな型台帳

※  高度な検索条件
  - OR、EXCLUDEの指定

※  タグ付け一覧管理
  - Bookmark

### ソースのディレクトリ構造

[refdemo]
- src
  - app         画面アプリ
  - util        汎用ユティリティ       
  - compo       共通コンポーネント（ソート、ページング、テーブル関連、タグ、検索、Fetch/Loader）
  - biz         ビジネスロジック（REFMa関連）
    - Ledger      台帳管理
    - Plan        計画管理
  - styles      デザイン要素
  - Images      イメージ、アイコン
  index.html
  package.json         npm
  types.d.ts           global type declarations         
  tsconfig.json        TypeScript config
  vite.config.js       vite bundler (builder)
  tailwind.config.js   TailwindCSS
  postcss.config.js    PostCSS
  eslint.config.js     ESLint
  cpt                  copy to target bash script

[fileserver]        ※ 開発環境にてREFMaシステムの代わりにデータ送信
  server.js         HTTP/GET File Server
  package.json
  - assets          REFMa/assetsのコピー

[MOC Design]


[REFMaシステム]
- REFMa
  - Content         ← デプロイターゲット
    - demo:         spa.js, spa.css
  - assets          ← HTTP GET/サーバ
    - Ledger
      - Ieq:        ie??.csv
    - LongTermPlan: insp??.csv
      - plans:      plans??.csv
  - Models:         *.cs
  - Views
    - Shared:       _Layout.cshtml
    - InspectionEquipmentListPage:
                    .cs, .cshtml
    - LTPSPAPage:   .cs, .cshtml
  - Controllers:    *.cs
  menu.xml

### 開発経緯
1. 最初の要件： 『検査設備台帳』画面(20列)をMVC化、その際にテーブルのソート、列幅調整機能を付ける。
2. MVC化によるView(cshtml)画面に、ReactのSPA(Single Page App)を組み込む実験に成功！
3. フロントエンドを分離して、ソートや絞り込み検索機能等を実装：非常にレスポンスのいい画面が作られる
4. 『長期作業計画』にも絞り込み検索機能を展開
5. 二つの画面を同時に発展させるため、共通要素のリファクタリングを実施、再利用可能なコンポーネント化
6. 長期はデータの種類が多いため、サーバからcsvフォーマットをリクエストして受信する構造に改造
7. 予実データ（多年度スケジュール）の表示こそ、フロントエンド化の真面目さを発揮できる場面だが開発中断。
8. パターン化されたソリューションの適用実験：『検査台帳』(47列)

※ 予実データのスケジュール表をフロントエンド化する課題
・今回、時間が足りなくて、テーブルを拡張してアイコンの表示だけで終了になったが、
 開発期間が確保できれば、以下の展開を考えられる。

1. データ構造の改変
  所管区別検査データに紐づく予実データと実績データのクエリー結果が画面表示に適していない。
  （予実データが多すぎるため、既存は頁毎の検査100件ずつ切り分けて転送）
  クライアント側での処理も可能だが、通信量を減らすためにも、サーバ側で画面表示に最適な構造のデータをAPIで提供する。
  （未来分の予実データはほとんどが周期的な空っぽのものなので、劇的に圧縮処理可能。ルール+例外）

2. CSS Grid基盤の座標システム構築
  既存のREFMaは、SVGで描画エンジン化した画面表示方式。
  今回のデモ版は、HTML Tableの延長＋CSS処理。
  理想は、2017年全てのブラウザーに適用されたCSS Gridの採用。
  （Tableは、行・列をDOM elementのデータとして配置するため隙の多い-sparse data-計画表示はリソースの浪費が大きい。
  SVGは、自由度が高すぎて、またEvent Handlingの処理問題等で、他のHTML/CSS要素と絡み合わせることが難しい。）
  CSS Gridを利用してスケジュール表示用の座標系を作り、ネイティヴDOM elementを配置することで、
  リソースを浪費せず、表示だけでなく柔軟なコントロールが可能な画面を作られる。

3. 長期（7年度分迄/月単位表示）→ 月間（3か月分迄/日単位表示）→ 作業実績（特定の予定日・実績日）
  Zoom-In/Outの画面展開：長期画面をZoom-Inしてシームレスに月間と作業実績に繋がる画面設計が可能。
  実績は、画面の表示スコープによってその都度データをリクエスト・受信、キャッシュ化が必要。

---
その他、フロントエンド化によって改善が見込められる機能
1. 「計画更新」と「変更履歴」
　最新台帳情報を引き合いに承認依頼済みの長期データに修正点を反映させる処理。
  現行では、実施予定月の移動操作が事前に承認依頼しておかないと無効化される。
  →フロントエンド化で、計算処理と画面操作による変更点を可視化、承認依頼の前にユーザが計画毎細かい調整作業可能。
  →変更履歴は別途の一覧だけでなく、長期の画面上に目印を付けて直感的に確認。
  →特殊なルールを所管区別に設定データ化することも可能

※ 以下は、既存画面システムとの連携なしに、DBとの直接のみで実装可能
2. 管理ツール画面
  異常データの補正、削除処理等を管理者権限で行える画面
  異常値を確認できる運営モニタリング機能

3. ダッシュボード
  経営資料、レポート、リアルタイム運営状況モニタリング
  分析DB(OLAP)の構築
 
